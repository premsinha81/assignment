const request = require('supertest');
const app = require('../src/app');

describe('API Endpoints', () => {
    it('should return BOM data', async () => {
        const response = await request(app).get('/api/bom');
        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('data');
    });

    it('should return compliance documents', async () => {
        const response = await request(app).get('/api/documents');
        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('data');
    });

    it('should return merged data', async () => {
        const response = await request(app).get('/api/merged');
        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('bom');
        expect(response.body).toHaveProperty('complianceData');
    });
});
