const express = require('express');
const app = express();
const cors = require('cors');
const port = process.env.PORT || 3000;

// Use CORS middleware
app.use(cors());

// Middleware
app.use(express.json());

const apiRoutes = require('./routes/apiRoutes');

// Sample route for testing
app.get('/', (req, res) => {
    res.send('API is running');
});

app.use('/api', apiRoutes);

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});

module.exports = app;
