const fs = require('fs');
const path = require('path');
const csv = require('csv-parser');
const xml2js = require('xml2js');

// Function to get BOM data
const getBOM = (req, res) => {
    const bomFilePath = path.join(__dirname, '../data/bom.json');
    fs.readFile(bomFilePath, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to read BOM data' });
        }
        const bomData = JSON.parse(data);
        res.json({ data: bomData });
    });
};

// Function to get compliance documents
const getDocuments = (req, res) => {
    const complianceFilePathCSV = path.join(__dirname, '../data/compliance.csv');
    const complianceFilePathXML = path.join(__dirname, '../data/compliance.xml');

    // Check for CSV file first
    fs.readFile(complianceFilePathCSV, 'utf8', (err, data) => {
        if (!err) {
            const results = [];
            fs.createReadStream(complianceFilePathCSV)
                .pipe(csv())
                .on('data', (row) => {
                    results.push(row);
                })
                .on('end', () => {
                    return res.json({ message: 'Compliance documents retrieved', data: results });
                });
        } else {
            // If CSV file not found, check for XML file
            fs.readFile(complianceFilePathXML, 'utf8', (err, data) => {
                if (!err) {
                    xml2js.parseString(data, (err, result) => {
                        if (err) {
                            return res.status(500).json({ error: 'Failed to parse XML data' });
                        }
                        return res.json({ message: 'Compliance documents retrieved', data: result });
                    });
                } else {
                    // If both files are missing
                    return res.status(404).json({ error: 'No compliance documents found' });
                }
            });
        }
    });
};

// Function to get merged data
const getMergedData = (req, res) => {
    const bomFilePath = path.join(__dirname, '../data/bom.json');
    const complianceFilePathCSV = path.join(__dirname, '../data/compliance.csv');

    // Read BOM data
    fs.readFile(bomFilePath, 'utf8', (err, bomData) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to read BOM data' });
        }
        const bom = JSON.parse(bomData);

        // Read compliance data
        fs.readFile(complianceFilePathCSV, 'utf8', (err, csvData) => {
            if (!err) {
                const results = [];
                fs.createReadStream(complianceFilePathCSV)
                    .pipe(csv())
                    .on('data', (row) => {
                        results.push(row);
                    })
                    .on('end', () => {
                        const components = bom.parts.map(part => {
                            const compliance = results.find(item => item.part_number === part.part_number);
                            return {
                                id: part.part_number,
                                substance: compliance ? compliance.substance : null,
                                mass: `${part.weight_g}g`,
                                threshold_ppm: compliance ? compliance.threshold_ppm : null,
                                status: compliance && part.weight_g > compliance.threshold_ppm ? "Non-Compliant" : "Compliant"
                            };
                        });
                        return res.json({ product: bom.product_name, components: components });
                    });
            } else {
                return res.status(404).json({ error: 'No compliance documents found' });
            }
        });
    });
};

module.exports = {
    getBOM,
    getDocuments,
    getMergedData
};
