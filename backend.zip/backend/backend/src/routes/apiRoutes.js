const express = require('express');
const router = express.Router();
const { getBOM, getDocuments, getMergedData } = require('../controllers/apiController');

// Define API endpoints
router.get('/bom', getBOM);
router.get('/documents', getDocuments);
router.get('/merged', getMergedData);

module.exports = router;
